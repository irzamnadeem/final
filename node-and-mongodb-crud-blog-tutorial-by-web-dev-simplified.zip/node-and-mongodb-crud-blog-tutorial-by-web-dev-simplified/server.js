const express = require("express");
const mongoose = require("mongoose");
const Article = require("./models/article");
const articleRouter = require("./routes/articles");
const methodOverride = require("method-override")
var bodyParser = require('body-parser');

const app = express();

username = "mianirzam"
password = "irzam123456789"

URL = `mongodb+srv://mianirzam:irzam123456789@cluster0.qywnf.mongodb.net/?retryWrites=true&w=majority`

mongoose.connect(URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(callback) {
    console.log("connection to db open")
    console.log(db.readyState)
});




app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.get("/", async(req, res) => {
    // res.send("Hello World!");

    // sort in descending order
    const articles = await Article.find().sort({ createdAt: "desc" });

    res.render("articles/index", { articles: articles });
});

app.use("/articles", articleRouter);

app.listen(3000);