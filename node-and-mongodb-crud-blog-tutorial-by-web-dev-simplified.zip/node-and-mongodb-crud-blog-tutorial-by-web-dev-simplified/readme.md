https://www.youtube.com/watch?v=1NrHkjlWVhM

How To Build A Markdown Blog Using Node.js, Express, And MongoDB
Tutorial by Web Dev Simplified

